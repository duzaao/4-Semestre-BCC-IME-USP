#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <pthread.h>
#include <inttypes.h>


#define LISTENQ 1
#define MAXLINE 4096
#define MAX_CLIENTS 200 // Número máximo de clientes
#define MAX_QUEUES 200 // Número máximo de filas

int numFilas = 0;

struct Client {
    int connfd; // Descritor de arquivo do socket do cliente
};


// Defina uma estrutura para armazenar informações do método queue.declare
struct MessageHeader {
    uint8_t type;    // Tipo da mensagem
    uint16_t channel; // Número do canal
    uint32_t length;  // Comprimento da mensagem
    uint16_t classe;   // Classe da mensagem
    uint16_t method;  // Método da mensagem
    uint16_t ticket; // Reservado
    uint8_t tamanho;
    char* queue;
    uint16_t tamanhox;
    uint16_t tamamnhoM;
    char* message;


};

struct messageHeader{
   
    uint8_t type;    // Tipo da mensagem
    uint16_t channel; // Número do canal
    uint32_t length;  // Comprimento da mensagem
    uint16_t classe;   // Classe da mensagem
    uint16_t method;  // Método da mensagem

};

struct DeclareQueue{
    uint8_t type;    // Tipo da mensagem
    uint16_t channel; // Número do canal
    uint32_t length;  // Comprimento da mensagem
    uint16_t classe;   // Classe da mensagem
    uint16_t method;  // Método da mensagem
    uint16_t ticket;
    uint8_t tamanho;
    char* queue;
};


struct BasicPublish{
    uint8_t type;    // Tipo da mensagem
    uint16_t channel; // Número do canal
    uint32_t length;  // Comprimento da mensagem
    uint16_t classe;   // Classe da mensagem
    uint16_t method;  // Método da mensagem
    uint16_t ticket;
    uint16_t tamFila;
    char* queue;
    uint8_t mandatory;
    // content header
    uint8_t typeCH;
    uint16_t channelCH;
    uint32_t lengthCH;
    uint16_t classID;
    uint16_t weight;
    uint64_t bodySize;
    uint16_t propertyFlags;
    uint8_t deliveryMode;
    // content body
    uint8_t typeCB;
    uint16_t channelCB;
    uint32_t lengthCB;
    char* message; // Mensagem
};



struct Consume{
    uint8_t type;    // Tipo da mensagem
    uint16_t channel; // Número do canal
    uint32_t length;  // Comprimento da mensagem
    uint16_t classe;   // Classe da mensagem
    uint16_t method;  // Método da mensagem
    uint16_t ticket;
    uint8_t tamanho;
    char* queue;
};

struct Node {
    int cliente;
    struct Node* next;
};

struct Queue {
    struct Node* front;
    struct Node* rear;
    struct Node* Atual;
    int size;
    int capacity;
};

struct QueueMap {
    char* names[MAX_QUEUES];
    int* ids[MAX_QUEUES];
    struct Queue* queues[MAX_QUEUES];
    int count;
};

struct ConsumeArgs {
    struct QueueMap* map;
    const char* filaNome;
    int cliente;
};

struct ThreadArgs {
    int connfd;
    struct QueueMap* map;
};


// Função para criar uma fila.
struct Queue* criarFila();

// Função para acessar uma fila.
void acessarFila(struct Queue* fila);

// Função para criar uma fila com um nome específico em um mapa de filas.
void criarFilaComNome(struct QueueMap* map, char* nome);

// Função para acessar uma fila por nome em um mapa de filas.
struct Queue* acessarFilaPorNome(struct QueueMap* map, const char* nome);

// Função que é executada em uma thread para consumir itens da fila.
void *consumeThread(void *args);

// Função para ler um quadro de dados a partir de uma conexão.
void readframe(int connfd);

// Função para ler um pacote com informações do cabeçalho e adicionar à fila apropriada.
void ReadPacote(int connfd, struct MessageHeader* msg, struct QueueMap* map);

// Função para lidar com a leitura de dados de uma conexão e adicioná-los à fila apropriada.
void leitura(int connfd, struct QueueMap* map);

// Função que é executada na thread principal.
void *thread_function(void *args);

// Função para inicializar uma fila com capacidade especificada.
void initializeQueue(struct Queue* queue, int capacity);

// Função para inserir um cliente na fila.
void insertNode(struct Queue* queue, int cliente);

// Função para obter o próximo nó da fila.
struct Node* getNextNode(struct Queue* queue);

// Função para remover um nó da fila com base no valor do cliente.
void removeNodeByCliente(struct Queue* queue, int cliente);

// Função para converter um número de host longo long para a ordem de rede.
uint64_t htonll(uint64_t hostlonglong);

// Função para criar um mapa de filas.
struct QueueMap* criarMapaFilas();