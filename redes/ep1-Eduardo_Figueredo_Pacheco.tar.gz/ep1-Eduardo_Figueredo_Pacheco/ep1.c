
#include "ep1.h"


// Função para inicializar uma fila circular
void initializeQueue(struct Queue* queue, int capacity) {
    queue->front = NULL;
    queue->rear = NULL;
    queue->Atual = NULL;
    queue->size = 0;
    queue->capacity = capacity;
}

// Função para inserir um nó no final da fila circular
void insertNode(struct Queue* queue, int cliente) {


    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->cliente = cliente;
    printf("Cliente %d conectado na fila.\n", cliente);
    newNode->next = NULL;

    if (queue->rear == NULL) {
        // Se a fila estiver vazia, o novo nó será o primeiro e o último
        queue->front = newNode;
        queue->rear = newNode;
        queue->Atual = newNode;
        newNode->next = newNode;
    } else {
        // Caso contrário, o novo nó se torna o último
        queue->rear->next = newNode;
        queue->rear = newNode;
        newNode->next = queue->front;
    }

    queue->size++;
    
}

// Função para pegar o próximo nó da fila circular
struct Node* getNextNode(struct Queue* queue) {
    if (queue->size == 0) {
        printf("Fila vazia.\n");
        return NULL;
    }

    if (queue->Atual == NULL) {


        // Procure o próximo nó que não seja NULL na fila
        struct Node* startNode = queue->front;

        do {
            queue->Atual = queue->Atual->next;
            if (queue->Atual != NULL) {
                printf("Atual: %d\n", queue->Atual->cliente);
                return queue->Atual;
            }
        } while (queue->Atual != startNode);

        return NULL;
    }

    // Se o nó atual não é NULL, atualize queue->Atual e retorne o nó atual
    queue->Atual = queue->Atual->next;
    return queue->Atual;
}

// Função para remover um nó com um cliente específico da fila circular
void removeNodeByCliente(struct Queue* queue, int cliente) {
    int removed = 0; // Inicializa uma variável para verificar se o cliente foi removido

    if (queue->front == NULL) {
        printf("Fila vazia, não foi possível remover um cliente.\n");
        return;
    }

    struct Node* current = queue->front;
    struct Node* prev = NULL;

    do {
        if (current->cliente == cliente) {
            // Encontrou o nó com o cliente especificado
            if (current == queue->front) {
                // Se o nó a ser removido é o nó da frente
                queue->front = current->next;
                queue->rear->next = queue->front; // Atualiza o próximo do último nó
                queue->Atual = queue->front; // Atualiza o nó atual
            } else if (current == queue->rear) {
                // Se o nó a ser removido é o último nó
                prev->next = current->next;
                queue->rear = prev; // Atualiza o último nó
                queue->rear->next = queue->front; // Atualiza o próximo do último nó
                queue->Atual = queue->front; // Atualiza o nó atual
            } else {
                // Se o nó a ser removido está no meio da fila
                prev->next = current->next;
            }

            free(current);
            removed = 1; // Cliente removido com sucesso
            queue->size--;
            break; // Saia do loop após remover o nó
        }

        prev = current;
        current = current->next;

    } while (current != queue->front); // Continue até retornar ao início da fila

    if (!removed) {
        printf("Cliente %d não encontrado na fila.\n", cliente);
    }
}



uint64_t htonll(uint64_t hostlonglong) {
    // Verifica se a máquina é little-endian (intel, x86)
    if (htonl(1) != 1) {
        uint32_t high_part = htonl((uint32_t)(hostlonglong >> 32));
        uint32_t low_part = htonl((uint32_t)hostlonglong);
        return ((uint64_t)low_part << 32) | high_part;
    } else {
        return hostlonglong;
    }
}

// Função para criar um mapa de filas
struct QueueMap* criarMapaFilas() {
    struct QueueMap* map = (struct QueueMap*)malloc(sizeof(struct QueueMap));
    map->count = 0;
    return map;
}



// Função para criar uma fila
struct Queue* criarFila() {
    struct Queue* fila = (struct Queue*)malloc(sizeof(struct Queue));
    fila->front = fila->rear = NULL;
    return fila;
}


// Função para acessar a fila
void acessarFila(struct Queue* fila) {
    struct Node* temp = fila->front;
    while (temp != NULL) {
        
        temp = temp->next;
    }
}


// Função para criar uma fila com um nome associado
void criarFilaComNome(struct QueueMap* map, char* nome) {

    if(strlen(nome)<1){
        printf("Nome da fila inválido.\n");
        return;
    }
    map->names[map->count] = strdup(nome);
    map->queues[map->count] = criarFila();
    map->count++;
    
    printf("Fila criada com sucesso de nome: %s\n", map->names[map->count - 1]);
    

}

// Função para acessar a fila por nome
struct Queue* acessarFilaPorNome(struct QueueMap* map, const char* nome) {
    
    for (int i = 0; i <= map->count; i++) {
        if(map->names[i]==NULL){
            continue;
        }
        if (strcmp(map->names[i], nome) == 0) {
            return map->queues[i];
        }
    }
    return NULL; // Retorna NULL se o nome não for encontrado
}


void *consumeThread(void *args) {


    struct ConsumeArgs* argumentos = (struct ConsumeArgs*)args;

    struct QueueMap* map = argumentos->map;
    const char* nomeFila = argumentos->filaNome;
    int cliente = argumentos->cliente;
    int x = 0;

    // Encontre a fila com o nome fornecido
    struct Queue* fila = acessarFilaPorNome(map, nomeFila);
    char recvline[MAXLINE + 1];
    ssize_t n;
    if (fila != NULL) {
        printf("Consumidor esperando por mensagens na fila %s\n", nomeFila);
        while (n=read(cliente,recvline,1)) {
            
    } 
    if(n==0){
        removeNodeByCliente(fila,cliente);
        
    }
}else{
    printf("Fila não encontrada.\n");
    return NULL;
}
    return NULL;
}


void readframe(int connfd){
    char recvline[MAXLINE + 1];
    uint32_t len;
    read(connfd, recvline, 7);
    

    memcpy(&(len), recvline + 3, sizeof(uint32_t));
    len = ntohl(len);

    read(connfd, recvline + 7, len);
    uint8_t end;
    read(connfd, &end, 1);

    

}

// Função para ler a msg
void ReadPacote(int connfd, struct MessageHeader* msg, struct QueueMap* map) {
    char recvline[MAXLINE + 1];
    ssize_t n;

    // Ler a mensagem do método queue.declare
    read(connfd, recvline, 7);
    

    // Separar e guardar as informações no struct
    memcpy(&(msg->type), recvline, sizeof(uint8_t));
    memcpy(&(msg->channel), recvline + 1, sizeof(uint16_t));
    memcpy(&(msg->length), recvline + 3, sizeof(uint32_t));

    msg->length = ntohl(msg->length);
    read(connfd, recvline + 7, msg->length);

    uint8_t end;
    read(connfd, &end, 1);
    if(end!=0xce){
        printf("erro no fim da mensagem\n");
        return;
    }

    memcpy(&(msg->classe), recvline + 7, sizeof(uint16_t));
    memcpy(&(msg->method), recvline + 9, sizeof(uint16_t));
    

    //Transformar os valores de network byte order para host byte order
    msg->channel = ntohs(msg->channel);
    msg->classe = ntohs(msg->classe);
    msg->method = ntohs(msg->method);
    



    // Se for um DeclareQueue, ler o tamanho e o nome da fila e criar a fila
    if(msg->method == 10){

        struct DeclareQueue DecQueue;

        //passar as informações do msg para DecQueue
        DecQueue.type = msg->type;
        DecQueue.channel = msg->channel;
        DecQueue.length = msg->length;
        DecQueue.classe = msg->classe;
        DecQueue.method = msg->method;


        memcpy(&(DecQueue.ticket), recvline + 11, sizeof(uint16_t));  
        memcpy(&(DecQueue.tamanho), recvline + 13, sizeof(uint8_t));


        // Ler o nome da fila
        DecQueue.queue = (char*)malloc(DecQueue.tamanho * sizeof(char));
        if (!DecQueue.queue) {
            perror("malloc :(\n");
            exit(8);
        }
        memcpy(DecQueue.queue, recvline + 14, DecQueue.tamanho);
        DecQueue.queue[DecQueue.tamanho] = '\0';

        uint8_t passive;
        memcpy(&(passive), recvline + 14 + DecQueue.tamanho, sizeof(uint8_t));
        uint32_t durable;
        memcpy(&(durable), recvline + 15 + DecQueue.tamanho, sizeof(uint32_t));



    // Aloque espaço para declareOk
    size_t declareOkSize = 23 + DecQueue.tamanho; // Tamanho total da mensagem
    char *declareOk = (char *)malloc(declareOkSize);
    if (!declareOk) {
        perror("malloc :(\n");
        exit(8);
    }
    DecQueue.method = 11; 
    
    // Preenche a mensagem declareOk
    DecQueue.channel = htons(DecQueue.channel);
    DecQueue.length = htonl(DecQueue.length+1);
    DecQueue.classe = htons(DecQueue.classe);
    DecQueue.method = htons(DecQueue.method);
    DecQueue.ticket = htons(DecQueue.ticket);

    declareOk[0] = DecQueue.type;
    *((uint16_t *)(declareOk + 1)) = DecQueue.channel;
    *((uint32_t *)(declareOk + 3)) = DecQueue.length;
    *((uint16_t *)(declareOk + 7)) = DecQueue.classe;
    *((uint16_t *)(declareOk + 9)) = DecQueue.method;
    *((uint8_t *)(declareOk + 11)) = strlen(DecQueue.queue);
    memcpy(declareOk + 12, DecQueue.queue, strlen(DecQueue.queue));
    *((uint32_t *)(declareOk + 12 + DecQueue.tamanho)) = 0;
    *((uint32_t *)(declareOk + 16 + DecQueue.tamanho)) = 0;

    declareOk[20 + DecQueue.tamanho] = end;

    // Envie a mensagem declareOk
    if (write(connfd, declareOk, declareOkSize-2) == -1) {
        perror("write :(\n");
        exit(6);
    }



    criarFilaComNome(map, DecQueue.queue);
    

        readframe(connfd);
    char* channelCloseOK = "\x01\x00\x01\x00\x00\x00\x04\x00\x14\x00\x29\xce";
    if (write(connfd, channelCloseOK, 12) == -1) {
        perror("write :(\n");
        exit(6);
    }
    
    readframe(connfd);
    
    // Resposta à mensagem: connection.close method --------------------------------
    char* connectionClose = "\x01\x00\x00\x00\x00\x00\x04\x00\x0a\x00\x33\xce";
    if (write(connfd, connectionClose, 12) == -1) {
        perror("write :(\n");
        exit(6);
    }
    
        return;
    }

    // Se for um BasicPublish, ler o tamanho, nome da fila e publicar a mensagem na fila
    if(msg->method == 40){


        struct BasicPublish BasicPub;

        //passar as informações do msg para BasicPub
        BasicPub.type = msg->type;
        BasicPub.channel = msg->channel;
        BasicPub.length = msg->length;
        BasicPub.classe = msg->classe;
        BasicPub.method = msg->method;



        memcpy(&(BasicPub.tamFila), recvline + 13, sizeof(uint16_t));
        BasicPub.tamFila = ntohs(BasicPub.tamFila);
        BasicPub.queue = (char*)malloc(BasicPub.tamFila * sizeof(char));
        if (!BasicPub.queue) {
                perror("malloc :(\n");
                exit(8);
        }
        memcpy(BasicPub.queue, recvline + 15, BasicPub.tamFila);
        BasicPub.queue[BasicPub.tamFila] = '\0';
        uint16_t mandatory;
        memcpy(&(mandatory), recvline + 15 + BasicPub.tamFila, sizeof(uint16_t));


        read(connfd, recvline, 7);
        memcpy(&(BasicPub.typeCH), recvline , sizeof(uint8_t));
        memcpy(&(BasicPub.channelCH), recvline + 1, sizeof(uint16_t));
        memcpy(&(BasicPub.lengthCH), recvline+ 3, sizeof(uint32_t));
        BasicPub.lengthCH = ntohl(BasicPub.lengthCH);

        read(connfd, recvline, BasicPub.lengthCH);
        memcpy(&(BasicPub.classID), recvline, sizeof(uint16_t));
        memcpy(&(BasicPub.weight), recvline + 2, sizeof(uint16_t));
        memcpy(&(BasicPub.bodySize), recvline + 10, sizeof(uint64_t));
        memcpy(&(BasicPub.propertyFlags), recvline + 12, sizeof(uint16_t));
        memcpy(&(BasicPub.deliveryMode), recvline + 13, sizeof(uint8_t));
        memcpy(&(BasicPub.typeCB), recvline + 14, sizeof(uint8_t));

        // Transformar os valores de network byte order para host byte order
        BasicPub.channelCH = ntohs(BasicPub.channelCH);
        BasicPub.classID = ntohs(BasicPub.classID);
        BasicPub.weight = ntohs(BasicPub.weight);
        BasicPub.bodySize = ntohl(BasicPub.bodySize);
        BasicPub.propertyFlags = ntohs(BasicPub.propertyFlags);


       read(connfd,&end,1);
       read(connfd, recvline, 7);
        memcpy(&(BasicPub.typeCB), recvline, sizeof(uint8_t));
        memcpy(&(BasicPub.channelCB), recvline+1, sizeof(uint16_t));
        memcpy(&(BasicPub.lengthCB), recvline+3, sizeof(uint32_t));
        // Transformar os valores de network byte order para host byte order
        BasicPub.channelCB = ntohs(BasicPub.channelCB);
        BasicPub.lengthCB = ntohl(BasicPub.lengthCB);
        BasicPub.message = (char*)malloc(BasicPub.lengthCB * sizeof(char));
        if (!BasicPub.message) {
                perror("malloc :(\n");
                exit(8);
        }
        
        
        read(connfd, BasicPub.message, BasicPub.lengthCB);
        BasicPub.message[BasicPub.lengthCB] = '\0';
        

        // usar a função acessarfilacomnome
        struct Queue* fila = acessarFilaPorNome(map, BasicPub.queue);
        if (fila == NULL) {
            printf("Fila não encontrada.\n");
            return;
        }

        // pegar o próximo nó da fila de clientes
        struct Node* nextNode = getNextNode(fila);
        if (nextNode == NULL) {
            printf("Nenhum cliente conectado para a fila %s",BasicPub.queue); 
            return;
        }

        // pegar o cliente do próximo nó
        int cliente = nextNode->cliente;

        
             
        // Aloque espaço para basicDeliver
        size_t basicDeliverSize = 1 + 2 + 4 + 2 + 2 + 2 + 31 + 8 + 1 + 2 + BasicPub.tamFila + 1 + 1 + 2 + 4 + 2 + 2 + 8 + 2 + 1 + 1 + 2 + 4 + BasicPub.lengthCB + 1;
        char *basicDeliver = (char *)malloc(basicDeliverSize);
        if (!basicDeliver) {
            perror("malloc :(\n");
            exit(8);
        }

        uint16_t del_type = 1;
        uint8_t del_channel = 1;
        BasicPub.method = 60; // Preencha o método como 60 (basicDeliver)
        BasicPub.classe = 60; // Preencha a classe como 60 (basicDeliver)
        char* consumerTag = "amq.ctag-FvOyIGi6gNkjQhfbhOC5DA";
        uint8_t tamanhoConsumerTag = 31;
        uint64_t deliveryTag = 1;
        uint8_t redelivered = 0;
        uint8_t end = 0xce;
        del_type = htons(del_type);
        BasicPub.length = 47 + BasicPub.tamFila ;

        BasicPub.classe = htons(BasicPub.classe);
        BasicPub.method = htons(BasicPub.method);
        BasicPub.tamFila = htons(BasicPub.tamFila);
        BasicPub.lengthCH = htonl(BasicPub.lengthCH);
        int tammm = BasicPub.lengthCB;
        BasicPub.bodySize = BasicPub.lengthCB;
        BasicPub.lengthCB = htonl(BasicPub.lengthCB);
        BasicPub.deliveryMode = 1;


        // Preencha a mensagem basicDeliver
        basicDeliver[0] = ntohs(del_type);
        *((uint16_t *)(basicDeliver + 1)) = ntohs(del_channel); 
        *((uint32_t *)(basicDeliver + 3)) = htonl(BasicPub.length); 
        *((uint16_t *)(basicDeliver + 7)) = BasicPub.classe; 
        *((uint16_t *)(basicDeliver + 9)) = BasicPub.method; 
        *((uint16_t *)(basicDeliver + 11)) = tamanhoConsumerTag;
        memcpy(basicDeliver + 12, consumerTag, tamanhoConsumerTag);
        *((uint64_t *)(basicDeliver + 43)) = htonll(deliveryTag); 
        basicDeliver[51] = redelivered;
        *((uint16_t *)(basicDeliver + 52)) = BasicPub.tamFila; 
        memcpy(basicDeliver + 54, BasicPub.queue, ntohs(BasicPub.tamFila)); 
        *((uint8_t *)(basicDeliver + 54 + ntohs(BasicPub.tamFila))) = end; 
        *((uint8_t *)(basicDeliver + 55 + ntohs(BasicPub.tamFila))) = BasicPub.typeCH;
        *((uint16_t *)(basicDeliver + 56 + ntohs(BasicPub.tamFila))) = ntohs(BasicPub.channelCH); 
        *((uint32_t *)(basicDeliver + 58 + ntohs(BasicPub.tamFila))) = BasicPub.lengthCH;
        *((uint16_t *)(basicDeliver + 62 + ntohs(BasicPub.tamFila))) = ntohs(BasicPub.classID); 
        *((uint16_t *)(basicDeliver + 64 + ntohs(BasicPub.tamFila))) = ntohs(BasicPub.weight); 
        *((uint64_t *)(basicDeliver + 66 + ntohs(BasicPub.tamFila))) = htonll(BasicPub.bodySize);
        *((uint16_t *)(basicDeliver + 74 + ntohs(BasicPub.tamFila))) = ntohs(BasicPub.propertyFlags); 
        basicDeliver[76 + ntohs(BasicPub.tamFila)] = BasicPub.deliveryMode;
        *((uint8_t *)(basicDeliver + 77 + ntohs(BasicPub.tamFila))) = end;
        *((uint8_t *)(basicDeliver + 78 + ntohs(BasicPub.tamFila))) = BasicPub.typeCB;
        *((uint16_t *)(basicDeliver + 79 + ntohs(BasicPub.tamFila))) = ntohs(BasicPub.channelCB); 
        *((uint32_t *)(basicDeliver + 81 + ntohs(BasicPub.tamFila))) = BasicPub.lengthCB;
        memcpy(basicDeliver + 85 + ntohs(BasicPub.tamFila), BasicPub.message, tammm);
        *((uint8_t *)(basicDeliver + 85 + ntohs(BasicPub.tamFila) + tammm)) = end;


        char* channelCloseOK = "\x01\x00\x01\x00\x00\x00\x04\x00\x14\x00\x29\xce";
        if (write(connfd, channelCloseOK, 12) == -1) {
            perror("write :(\n");
            exit(6);
        }
        readframe(connfd);
        write(cliente, basicDeliver, basicDeliverSize);
        
        char* connectionClose = "\x01\x00\x00\x00\x00\x00\x04\x00\x0a\x00\x33\xce";
        if (write(connfd, connectionClose, 12) == -1) {
            perror("write :(\n");
            exit(6);
        }
        


        
        
        readframe(cliente);
        


        
        

        /*// Resposta à mensagem: connection.close method --------------------------------
        char* connectionClose = "\x01\x00\x00\x00\x00\x00\x04\x00\x0a\x00\x33\xce";
        if (write(connfd, connectionClose, 12) == -1) {
            perror("write :(\n");
            exit(6);
        }*/



        return;

    }


    // Se for um consume : ler o tamanho, nome da fila e a mensagem publicada e criar uma thread
    if(msg->method==20){
        struct Consume Consume;

        //passar as informações do msg para Consume
        Consume.type = msg->type;
        Consume.channel = msg->channel;
        Consume.length = msg->length;
        Consume.classe = msg->classe;
        Consume.method = msg->method;
    
        memcpy(&(Consume.ticket), recvline + 11, sizeof(uint16_t));
        memcpy(&(Consume.tamanho), recvline + 13, sizeof(uint8_t));
        
        Consume.ticket = ntohs(Consume.ticket);
        Consume.queue = (char*)malloc(Consume.tamanho * sizeof(char));
        if (!Consume.queue) {
                perror("malloc :(\n");
                exit(8);
        }
        memcpy(Consume.queue, recvline + 14, Consume.tamanho);
        Consume.queue[Consume.tamanho] = '\0';


        // Aloque espaço para consumeOk
        size_t consumeOkSize = 44; // Tamanho total da mensagem
        char *consumeOk = (char *)malloc(consumeOkSize);
        if (!consumeOk) {
            perror("malloc :(\n");
            exit(8);
        }
        Consume.method = 21; // Preencha o método como 21 (consumeOk)
        char* ctag = "amq.ctag-m5CfsJ9yfdm6ONbi_E2heA";
        uint8_t tamanhoCtag = 31;
        
        // Preencha a mensagem consumeOk
        Consume.channel = htons(Consume.channel);
        Consume.length = htonl(36);
        Consume.classe = htons(Consume.classe);
        Consume.method = htons(Consume.method);
        Consume.ticket = htons(Consume.ticket);
        consumeOk[0] = Consume.type;
        *((uint16_t *)(consumeOk + 1)) = Consume.channel;
        *((uint32_t *)(consumeOk + 3)) = Consume.length;
        *((uint16_t *)(consumeOk + 7)) = Consume.classe;
        *((uint16_t *)(consumeOk + 9)) = Consume.method;
        *((uint8_t *)(consumeOk + 11)) = tamanhoCtag;
        memcpy(consumeOk + 12, ctag, tamanhoCtag);
        consumeOk[43] = '\xce';


        // Envie a mensagem consumeOk
        if (write(connfd, consumeOk, consumeOkSize) == -1) {
            perror("write :(\n");
            exit(6);
        }

        free(consumeOk); 

        


        //pegar fila 
        struct Queue* fila = acessarFilaPorNome(map, Consume.queue);
        if (fila == NULL) {
            printf("Fila não encontrada.\n");
            return;
        }
        //fazer thread pra ler a fila e pra vericiar mensagens do socket
        //criar novo nó usando a função;
        insertNode(fila, connfd);


        // Crie a thread e passe os dados necessários (a struct Consume)
        pthread_t thread2;
        struct ConsumeArgs args;
        args.map = map;
        args.filaNome = Consume.queue;
        args.cliente = connfd;

       




        if (pthread_create(&thread2, NULL, consumeThread, &args) != 0) {
            perror("pthread_create :(\n");
            exit(1);
        }


       
        pthread_join(thread2, NULL);

                readframe(connfd);
        char* channelCloseOK = "\x01\x00\x01\x00\x00\x00\x04\x00\x14\x00\x29\xce";
        if (write(connfd, channelCloseOK, 12) == -1) {
            perror("write :(\n");
            exit(6);
        }



    }


}


void leitura(int connfd, struct QueueMap* map){

            

            // Leitura da mensagem header do AMQP -----------------------------------------------------
            char recvline[MAXLINE + 1];
            ssize_t n;
            if ((n = read(connfd, recvline, 8)) == -1) {
                perror("read :(\n");
                exit(6);
            }
            

            // Verificação da mensagem header do AMQP
            char* header = "AMQP\x00\x00\x09\x01";
            if (strncmp(recvline, header, strlen(header)-1) != 0) {
                // Responder com a mensagem header do AMQP se não for válida
                if (write(connfd, header, strlen(header)) == -1) {
                    perror("write :(\n");
                    exit(6);
                }
                close(connfd);
                exit(10);
            }

            //  Connection.Start method --------------------------------
           
           
            char* start = "\x01\x00\x00\x00\x00\x00\x25\x00\x0a\x00\x0a\x00\x09\x00\x00\x00\x00"\
  "\x00\x00\x00\x0e\x41\x4d\x51\x50\x4c\x41\x49\x4e\x20\x50\x4c\x41\x49\x4e"\
  "\x00\x00\x00\x05\x65\x6e\x5f\x55\x53\xce";
            if (write(connfd, start,45) == -1) {
                perror("write :(\n");
                exit(6);
            }

            
            // Leitura da resposta do cliente
            readframe(connfd);
            recvline[n] = '\0';

            //  Connection.Tune method --------------------------------

            char* tune = "\x01\x00\x00\x00\x00\x00\x0c\x00\x0a\x00\x1e\x07\xff\x00\x02\x00" \
"\x00\x00\x3c\xce";
            if (write(connfd, tune, 20) == -1) {
                perror("write :(\n");
                exit(6);
            }

            // Leitura da resposta do cliente  
            readframe(connfd);

            //  Connection.Open method --------------------------------
            
            
            char* openOK = "\x01\x00\x00\x00\x00\x00\x05\x00\x0a\x00\x29\x00\xce";
            if (write(connfd, openOK, 13) == -1) {
                perror("write :(\n");
                exit(6);
            }

            // Leitura do channel open
            readframe(connfd);

            

            //  Channel.Open method --------------------------------
            
            
            char* channelOpenOK = "\x01\x00\x01\x00\x00\x00\x08\x00\x14\x00\x0b\x00\x00\x00\x00\xce";
            if (write(connfd, channelOpenOK, 16) == -1) {
                perror("write :(\n");
                exit(6);
            }

            readframe(connfd);
            //  queue.declare method --------------------------------
            // ler e separar a mensagem em method,  channeal, length, class, method
            struct MessageHeader msg = {0};

     


            
            // Agora, depois de ler a mensagem do método queue.declare, chame a função para processá-la
            ReadPacote(connfd, &msg, map);
            



}


// fazer uma função para a thread de ler novas mensagens

void *thread_function(void *args) {

    struct ThreadArgs* argumentos = (struct ThreadArgs*)args;

    int connfd = argumentos->connfd;
    struct QueueMap* map = argumentos->map;


    printf("[Uma conexão aberta]\n");

    leitura(connfd, map);
    
            
    printf("[Uma conexão fechada]\n");

    close(connfd);
    return NULL;
}


int main(int argc, char** argv) {
    int listenfd, connfd;
    struct sockaddr_in servaddr;
    pid_t childpid;
    char recvline[MAXLINE + 1];
    ssize_t n;

    
    //inicializar o map 
    struct QueueMap* map = criarMapaFilas();
    if (!map) {
        perror("malloc :(\n");
        exit(8);
    }
    

    if (argc != 2) {
        fprintf(stderr, "Uso: %s <Porta>\n", argv[0]);
        fprintf(stderr, "Vai rodar um servidor de echo na porta <Porta> TCP\n");
        exit(1);
    }

    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket :(\n");
        exit(2);
    }

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(atoi(argv[1]));
    

    if (bind(listenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1) {
        perror("bind :(\n");
        exit(3);
    }

    if (listen(listenfd, LISTENQ) == -1) {
        perror("listen :(\n");
        exit(4);
    }

   printf("[Servidor no ar. Aguardando conexões na porta %s]\n", argv[1]);
    printf("[Para finalizar, pressione CTRL+c ou rode um kill ou killall]\n");

    struct Client** clients = (struct Client**)malloc(MAX_CLIENTS * sizeof(struct Client*));
    if (!clients) {
        perror("malloc :(\n");
        exit(7);
    }

    int num_clients = 0;

    for (;;) {
        if ((connfd = accept(listenfd, (struct sockaddr*)NULL, NULL)) == -1) {
            perror("accept :(\n");
            exit(5);
        }

        
            // iniciar uma thread com argumentos
            struct ThreadArgs args;
            args.connfd = connfd;
            args.map = map;

            pthread_t thread;
            if (pthread_create(&thread, NULL, thread_function, &args) != 0) {
                perror("pthread_create :(\n");
                exit(1);
            }
            
    }



    exit(0);
}



